The PPTX is the cleanly formatted challenge presentation. `presentation_outline.md` contains the slide structure in text form.
