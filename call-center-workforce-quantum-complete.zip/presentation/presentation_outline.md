# Presentation outline

1. Problem and scoring objective
2. Synthetic call-center data
3. Demand forecasting
4. Erlang-C staffing requirement
5. Binary mathematical formulation
6. Constraints: shifts, skills, breaks, overtime
7. QUBO derivation
8. Qiskit QAOA architecture
9. Queue simulation
10. Classical CP-SAT baseline
11. Workforce planner UI
12. Benchmark and trade-offs
13. Limitations / hardware extension
14. Conclusion
